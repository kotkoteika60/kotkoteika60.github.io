import os
from PyQt5.Qsci import *


filetypes = [
    {'name' : 'Plain text',
     'lexer' : QsciLexerBash,
     'ext' : ['.txt'],
    },
    {'name' : 'Batch Script',
     'lexer' : QsciLexerBatch,
     'ext' : ['.bat', '.sh', '.zsh']
    },
    {'name' : 'C/C++',
     'lexer' : QsciLexerCPP,
     'ext' : ['.c', '.h', '.cpp', '.hpp']
    },
    {'name' : 'C#',     
     'lexer' : QsciLexerCSharp,
     'ext' : ['.cs']
    },
    {'name' : 'CSS',    
     'lexer' : QsciLexerCSS,
     'ext' : ['.css']
    },
    {'name' : 'CMake',  
     'lexer' : QsciLexerCMake,
     'ext' : ['.cmake'],
    },
    {'name' : 'HTML',   
     'lexer' : QsciLexerHTML,
     'ext' : ['.html', '.htm']
     },
    {'name' : 'Java',   
     'lexer' : QsciLexerJava,
     'ext' : ['.java']
     },
    {'name' : 'JS/JSON',
     'lexer' : QsciLexerJavaScript,
     'ext' : ['.js', '.json']
     },
    {'name' : 'Python', 
     'lexer' : QsciLexerPython,
     'ext' : ['.py', '.pyw'],
     },
    {'name' : 'Lua',    
     'lexer' : QsciLexerLua,
     'ext' : ['.lua'],
     },
    {'name' : 'XML',    
     'lexer' : QsciLexerXML,
     'ext' : ['.xml'],
     },
    {'name' : 'YAML',   
     'lexer' : QsciLexerYAML,
     'ext' : ['.yml'],
     },
    {'name' : 'Diff',   
     'lexer' : QsciLexerDiff,
     'ext' : ['.dif'],
    },
]

def get_ft(fname):
    name, ext = os.path.splitext(fname)
    print(name, ext)
    for ft in filetypes:
        if (ext[0] == '.') and (ext in ft.get('ext', [])):
            return ft
    return {}

class DefaultFile:
    def open(self, path, editor, encoding="utf8"):
        filetype = get_ft(path)
        if filetype:
            editor.set_lex(filetype['lexer']())
        try:
            return open(path, "r", encoding=encoding).read()
        except UnicodeDecodeError:
            return open(path, "r", encoding="cp1251").read()
        except Exception as e:
            print(e)
            return ""

    def save(self, path, data, encoding="utf8"):
        try:
            f = open(path, "w", encoding=encoding).write(data)
            f.close()
            return 1
        except Exception as e:
            print(e)
            return 0