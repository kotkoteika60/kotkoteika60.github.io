import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.Qsci import *
from PyQt5 import QtPrintSupport
from filetypes import DefaultFile, filetypes
from editor import CodeEditor
import re

class MainWnd(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.filename = None
        self.file_open = False

        self.fileio = DefaultFile()
        self.editor = CodeEditor()
        
        self.setWindowTitle("notepad+-")
        self.setGeometry(100, 100, 800, 500)
        self.setMinimumSize(200, 200)
        self.build_ui()

    def build_ui(self):
        # Menu Bar
        menu_bar = self.menuBar()
        file_menu = menu_bar.addMenu('File')

        new_menu = QAction('New', self)
        new_menu.setShortcut('Ctrl+N')
        new_menu.triggered.connect(self.new)
        file_menu.addAction(new_menu)

        open_menu = QAction('Open', self)
        open_menu.setShortcut('Ctrl+O')
        open_menu.triggered.connect(self.open)
        file_menu.addAction(open_menu)


        save_menu = QAction('Save', self)
        save_menu.setShortcut('Ctrl+S')
        save_menu.triggered.connect(self.save)
        file_menu.addAction(save_menu)

        edit_menu = menu_bar.addMenu("Edit")

        copy_menu = QAction('Copy', self)
        copy_menu.setShortcut('Ctrl+C')
        copy_menu.triggered.connect(self.copy)
        edit_menu.addAction(copy_menu)

        cut_menu = QAction('Cut', self)
        cut_menu.setShortcut('Ctrl+X')
        cut_menu.triggered.connect(self.cut)
        edit_menu.addAction(cut_menu)

        paste_menu = QAction('Paste', self)
        paste_menu.setShortcut('Ctrl+V')
        paste_menu.triggered.connect(self.paste)
        edit_menu.addAction(paste_menu)

        lexer_menu = edit_menu.addMenu('Lexer')
        for i in filetypes:
            _act = QAction(i['name'], self)
            _act.triggered.connect(self.apply_lexer)
            lexer_menu.addAction(_act)

        test_themegen = QAction('Random theme', self)
        test_themegen.triggered.connect(self.editor.random_theme_gen)
        edit_menu.addAction(test_themegen)

        about_menu = menu_bar.addMenu("Help")
        help_menu = QAction("About", self)
        help_menu.setShortcut('F7')
        help_menu.triggered.connect(self.about)

        about_menu.addAction(help_menu)

        vbox = QVBoxLayout()
        vbox.addWidget(self.editor)
        vbox.setStretchFactor(self.editor, 1)
        vbox.setContentsMargins(0, 0, 0, 0)

        central_widget = QWidget()
        central_widget.setLayout(vbox)
        self.setCentralWidget(central_widget)

    def apply_lexer(self):
        lex_name = self.sender().text()
        for i in filetypes:
            if i["name"] == lex_name:
                self.editor.set_lex(i["lexer"]())

    def copy(self):
        self.editor.copy()

    def cut(self):
        self.editor.cut()

    def paste(self):
        self.editor.paste()

    def new(self):
        self.filename = None
        self.file_open = False
        self.editor.clear()

    def open(self):
        open_file = QFileDialog.getOpenFileName(self, 'Open')
        if open_file != ('', ''):
            self.editor.setText("")
            self.file_open = True
            self.filename = open_file[0]
            self.editor.setText(self.fileio.open(self.filename, self.editor))
            self.post_save()

    def about(self):
        about_dialog = QMessageBox()
        about_dialog.about(self, "о блокноте", "<h1>Notepad+-</h1><h2>v1.0</h2>")

    def save(self):
        save_file = None
        save_file = QFileDialog.getSaveFileName(self, 'Save')
        self.filename = save_file[0]
        self.file_open = True
        self.fileio.save(self.filename, self.editor.text())
        self.post_save()

    def post_save(self):
        window_title = "notepad+-  - " + self.filename
        self.setWindowTitle(window_title)

    def closeEvent(self, event):
        pass


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle('Oxygen')
    main_window = MainWnd()
    main_window.setWindowIcon(QIcon("logo.png"))
    main_window.show()
    sys.exit(app.exec_())

