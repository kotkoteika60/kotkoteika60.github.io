from PyQt5.Qsci import *
from PyQt5.QtGui import QColor, QFont
import random
from pprint import pprint


best_theme_ever = {
 1: '#e9d70b',
 2: '#46EF67',
 3: '#18de4d',
 4: '#fcec00', #fcec00
 5: '#DC3431',
 6: '#fcec00',
 7: '#18de4d',
 8: '#20CC6D',
 9: '#FF7100',
 10: '#A8C06C',
 11: '#44C8D1',
 12: '#fcec00',
 13: '#fcec00',
 14: '#01e8bd',
 15: '#B307CA',
 16: '#20E7A1',
 17: '#787384',
 18: '#94CA94',
 19: '#53A3B4'
}


def random_color():
    return "#" + ''.join([random.choice('0123456789ABCDEF') for j in range(6)])


class CodeEditor(QsciScintilla):
    def __init__(self):
        super().__init__()
        self.setUtf8(True)
        self.setWrapMode(QsciScintilla.WrapWord)
        self.setWrapVisualFlags(QsciScintilla.WrapFlagByText)
        self.setWrapIndentMode(QsciScintilla.WrapIndentIndented)
        self.setIndentationsUseTabs(False)
        self.setTabWidth(4)
        self.setIndentationGuides(True)
        self.setTabIndents(True)
        self.setAutoIndent(True)
        self.setCaretForegroundColor(QColor("#ffffffff"))
        self.setCaretLineVisible(True)
        self.setCaretLineBackgroundColor(QColor("#1f31f75c"))
        self.setCaretWidth(2)
        self.setMarginType(3, QsciScintilla.NumberMargin)
        self.setMarginWidth(3, "9999")
        self.setMarginsForegroundColor(QColor("#ffe0e0e0"))
        self.setMarginsBackgroundColor(QColor("#ff383838"))
        self.lex = QsciLexerBash()
        self.apply_theme(best_theme_ever, self.lex)

    def set_lex(self, lexer):
    	self.lex = lexer
    	self.apply_theme(best_theme_ever, self.lex)

    def apply_theme(self, theme={}, lexer=None):
        font = QFont("Consolas", 8)
        lexer.setDefaultPaper(QColor("#26292c"))
        lexer.setDefaultColor(QColor("#f9f9f9"))
        lexer.setDefaultFont(font)
        lexer.setColor(QColor("#ffffff"), 0)
        lexer.setPaper(QColor("#26292c"), 0)
        lexer.setFont(font, 0)
        if theme and lexer:
        	for i in theme.keys():
        	    lexer.setColor(QColor(theme[i]), i)
        	    lexer.setPaper(QColor("#26292c"), i)
        	    lexer.setFont(font, i)
        	self.setLexer(lexer)
        self.setMarginsForegroundColor(QColor("#ffe0e0e0"))
        self.setMarginsBackgroundColor(QColor("#ff383838"))

    def random_theme_gen(self, _=None):  # иногда темы получаются довольно смотрибельными. но в любом случае надо будет править вручную
        test_theme = {}
        for i in range(1, 30):
            if self.lex.description(i):
                test_theme[i] = random_color()
        pprint(test_theme)
        self.apply_theme(test_theme, self.lex)